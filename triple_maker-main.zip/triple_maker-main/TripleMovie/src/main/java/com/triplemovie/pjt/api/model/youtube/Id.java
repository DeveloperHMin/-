package com.triplemovie.pjt.api.model.youtube;

public class Id {
    private String kind;
    private String videoId;
    
    
	public String getVideoId() {
		return videoId;
	}
	public void setVideoId(String videoId) {
		this.videoId = videoId;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}

}
