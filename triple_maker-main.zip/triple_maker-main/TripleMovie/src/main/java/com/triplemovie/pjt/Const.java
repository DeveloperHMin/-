package com.triplemovie.pjt;

public class Const {
	public static String main = null;
	final public static String MOVIERANK = "movieRank";
	final public static String LOGIN_USER = "loginUser";	
}
