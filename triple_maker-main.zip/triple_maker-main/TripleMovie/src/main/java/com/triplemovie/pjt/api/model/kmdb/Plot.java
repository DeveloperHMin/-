package com.triplemovie.pjt.api.model.kmdb;

public class Plot {
    private String plotLang;
    private String plotText;
    
	public String getPlotLang() {
		return plotLang;
	}
	public void setPlotLang(String plotLang) {
		this.plotLang = plotLang;
	}
	public String getPlotText() {
		return plotText;
	}
	public void setPlotText(String plotText) {
		this.plotText = plotText;
	}
    
    
}
