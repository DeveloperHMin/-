package com.triplemovie.pjt.api.model.kmdb;

public class Plots {
	private Plot[] plot;

	public Plot[] getPlot() {
		return plot;
	}

	public void setPlot(Plot[] plot) {
		this.plot = plot;
	}
	
	
}
