package com.triplemovie.pjt.api.model.kobis.info;

//심의정보
public class Audit {
	private String auditNo;
    private String watchGradeNm;
    
	public String getAuditNo() {
		return auditNo;
	}
	public void setAuditNo(String auditNo) {
		this.auditNo = auditNo;
	}
	public String getWatchGradeNm() {
		return watchGradeNm;
	}
	public void setWatchGradeNm(String watchGradeNm) {
		this.watchGradeNm = watchGradeNm;
	}
    
    
}
