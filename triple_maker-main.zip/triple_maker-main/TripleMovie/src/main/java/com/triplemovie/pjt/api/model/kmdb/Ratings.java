package com.triplemovie.pjt.api.model.kmdb;

public class Ratings {
	private Rating[] rating;

	public Rating[] getRating() {
		return rating;
	}

	public void setRating(Rating[] rating) {
		this.rating = rating;
	}
	
}
