package com.triplemovie.pjt.api.model.kmdb;

public class Actors {
	private Actor[] actor;

	public Actor[] getActor() {
		return actor;
	}

	public void setActor(Actor[] actor) {
		this.actor = actor;
	}
	
	
}
