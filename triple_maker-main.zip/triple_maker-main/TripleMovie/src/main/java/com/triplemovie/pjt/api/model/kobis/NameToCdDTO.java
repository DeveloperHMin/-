package com.triplemovie.pjt.api.model.kobis;

public class NameToCdDTO {
    private MovieListResult movieListResult;

	public MovieListResult getMovieListResult() {
		return movieListResult;
	}

	public void setMovieListResult(MovieListResult movieListResult) {
		this.movieListResult = movieListResult;
	}
    
    
    
    

}
