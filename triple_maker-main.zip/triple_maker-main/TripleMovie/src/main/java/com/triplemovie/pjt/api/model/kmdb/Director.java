package com.triplemovie.pjt.api.model.kmdb;

public class Director {
    private String directorNm;
    private String directorEnNm;
    private String directorId;
	public String getDirectorNm() {
		return directorNm;
	}
	public void setDirectorNm(String directorNm) {
		this.directorNm = directorNm;
	}
	public String getDirectorEnNm() {
		return directorEnNm;
	}
	public void setDirectorEnNm(String directorEnNm) {
		this.directorEnNm = directorEnNm;
	}
	public String getDirectorId() {
		return directorId;
	}
	public void setDirectorId(String directorId) {
		this.directorId = directorId;
	}
    
    
}
