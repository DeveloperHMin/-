package com.triplemovie.pjt.api.model.kmdb;

public class Directors {
	private Director[] director;

	public Director[] getDirector() {
		return director;
	}

	public void setDirector(Director[] director) {
		this.director = director;
	}
}
