package com.triplemovie.pjt.api.model.kobis;

public class KobisDTO {
	private BoxOfficeResult boxOfficeResult;

	public BoxOfficeResult getBoxOfficeResult() {
		return boxOfficeResult;
	}

	public void setBoxOfficeResult(BoxOfficeResult boxOfficeResult) {
		this.boxOfficeResult = boxOfficeResult;
	}
	
	
}
