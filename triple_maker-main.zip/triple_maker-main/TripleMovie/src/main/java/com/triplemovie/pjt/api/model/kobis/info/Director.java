package com.triplemovie.pjt.api.model.kobis.info;

//감독
public class Director {
	private String peopleNm;
    private String peopleNmEn;
    
	public String getPeopleNm() {
		return peopleNm;
	}
	public void setPeopleNm(String peopleNm) {
		this.peopleNm = peopleNm;
	}
	public String getPeopleNmEn() {
		return peopleNmEn;
	}
	public void setPeopleNmEn(String peopleNmEn) {
		this.peopleNmEn = peopleNmEn;
	}
	
    
    
    
}
