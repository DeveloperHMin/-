package com.triplemovie.pjt.api.model.kobis.info;

public class Genre {
	private String genreNm;

	public String getGenreNm() {
		return genreNm;
	}

	public void setGenreNm(String genreNm) {
		this.genreNm = genreNm;
	}
	
	
}
