package com.triplemovie.pjt.api.model.kobis.info;

public class MovieInfoDTO {
	private MovieInfoResult movieInfoResult;

	public MovieInfoResult getMovieInfoResult() {
		return movieInfoResult;
	}

	public void setMovieInfoResult(MovieInfoResult movieInfoResult) {
		this.movieInfoResult = movieInfoResult;
	}
	

}
