package com.triplemovie.pjt.api.model.kmdb;

public class Actor {
    private String actorNm;
    private String actorEnNm;
    private String actorId;
	public String getActorNm() {
		return actorNm;
	}
	public void setActorNm(String actorNm) {
		this.actorNm = actorNm;
	}
	public String getActorEnNm() {
		return actorEnNm;
	}
	public void setActorEnNm(String actorEnNm) {
		this.actorEnNm = actorEnNm;
	}
	public String getActorId() {
		return actorId;
	}
	public void setActorId(String actorId) {
		this.actorId = actorId;
	}
    
    
    
}
