CREATE TABLE t_cinema(
		i_movie INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
		movieId VARCHAR(50),
		movieSeq VARCHAR(50),
		movieNm VARCHAR(100),
		totalSeat INT UNSIGNED DEFAULT 100,
		room INT UNSIGNED,
		s_dt INT UNSIGNED,
		e_dt INT UNSIGNED,
		r_dt VARCHAR(10)
);


CREATE TABLE t_user(
	i_user INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
	user_id VARCHAR(50) NOT NULL UNIQUE,
	user_pw VARCHAR(100) NOT NULL,
	salt VARCHAR(80) NOT NULL,
	nick_nm VARCHAR(50) NOT NULL UNIQUE,
	age INT UNSIGNED,
	gender INT UNSIGNED,
	r_dt DATETIME DEFAULT NOW()
);

CREATE TABLE t_cmt(
	i_cmt INT UNSIGNED KEY AUTO_INCREMENT,
	i_user INT UNSIGNED,
	movieId VARCHAR(50),
	movieSeq VARCHAR(50),
	ctnt VARCHAR(300) NOT NULL,
	FOREIGN KEY (i_user) REFERENCES t_user(i_user)
);


CREATE TABLE t_cmt_favorite (
	i_cmt INT UNSIGNED,
	i_user INT UNSIGNED,
	seq INT  UNSIGNED,
	PRIMARY KEY (i_cmt, i_user),
    FOREIGN KEY ( i_cmt ) REFERENCES t_cmt  ( i_cmt ),
	FOREIGN KEY ( i_user ) REFERENCES t_user  ( i_user ) 
);

CREATE TABLE t_user_ticket(
   i_ticket INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
   i_user INT UNSIGNED,
   i_movie INT UNSIGNED,
   adultCnt INT UNSIGNED,
   studentCnt INT UNSIGNED,
   FOREIGN KEY (i_user) REFERENCES t_user(i_user),
   FOREIGN KEY (i_movie) REFERENCES t_cinema(i_movie)
);


CREATE TABLE t_user_seats(
	i_ticket INT UNSIGNED,
	seq INT UNSIGNED,
	seat VARCHAR(10),
	PRIMARY KEY(i_ticket, seat),
	FOREIGN KEY (i_ticket) REFERENCES t_user_ticket(i_ticket)
);